from __future__ import absolute_import

from lib import util
from . import kodigui

kodigui.MONITOR = util.MONITOR
